
import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Thabiso
 */
public class Dateutil {
    
     public static java.util.Date addDays(Date day, int days)
    {
        Calendar cal = Calendar.getInstance();
        cal.setTime(day);
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
        cal.add(Calendar.DATE, days); //minus number would decrement the days
         return cal.getTime();
    }
     
     
    
}
