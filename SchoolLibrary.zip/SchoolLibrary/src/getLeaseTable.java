
import java.sql.Date;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Thabiso
 */
public class getLeaseTable {
    private int leaseNo, bookNo,studentNo;
    private String bookTitle;
    Date  issueDate,dueDate;
    
    public getLeaseTable(int leaseNo, int bookNo,int studentNo,String bookTitle,Date issueDate,Date dueDate){
        this.leaseNo=leaseNo;
        this.bookNo=bookNo;
        this.studentNo=studentNo;
        this.bookTitle=bookTitle;
        this.issueDate=issueDate;
        this.dueDate=dueDate;
    }
    
    public int getLeaseNo(){
        return leaseNo;
    }
    
     public int getBookNo(){
        return bookNo;
    }
     
      public int getStudentNo(){
        return studentNo;
    }
      
     public String getBookTitle(){
         return bookTitle;
     } 
     
     public Date getIssueDate(){
         return issueDate;
     }
    
     public Date getDueDate(){
         return dueDate;
     }
}
