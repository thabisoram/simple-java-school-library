/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Thabiso
 */
public class getABooks {
    private int bookid, edition, quantity;
    private String title, author, publisher;
    
    public getABooks(int bookid, String title,String author, int edition,String publisher, int quantity){
        this.bookid=bookid;
        this.title=title;
        this.author=author;
        this.edition=edition;
        this.publisher=publisher;
        this.quantity=quantity;
    }
    
    public int getBookId(){
        return bookid;
    }
    
    public String getTitle(){
        return title;
    }
    
    public String getAuthor(){
        return author;
    }
    
    public int getEdition(){
        return edition;
    }
    
    public String getPublisher(){
        return publisher;
    }
    
    public int getQuantity(){
        return quantity;
    }
}
